package com.example.mqtt_flower;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    private String host = "tcp://a1JxOUTX7DV.iot-as-mqtt.cn-shanghai.aliyuncs.com:1883";
    private String userName = "app-1&a1JxOUTX7DV";
    private String passWord = "abf77459bc63e105f1ff225dc3ed38f554a631f2";
    private String mqtt_id = "1|securemode=3,signmethod=hmacsha1,timestamp=789|";
    private String mqtt_sub_topic = "/a1JxOUTX7DV/app-1/user/wendu"; //订阅温度度话题
    private String mqtt_sub_topic1 = "/a1JxOUTX7DV/app-1/user/shidu"; //订阅湿度话题
    private String mqtt_pub_topic1 = "/a1JxOUTX7DV/app-1/user/shuibeng";//发布水泵开关话题

    private int led_flag =1;//作为开关灯的判断
    private ScheduledExecutorService scheduler;
    private MqttClient client;
    private MqttConnectOptions options;
    private Handler handler;

    private Button btn_1;   //类似于单片机开发里面的   参数初始化
    private ImageView image_1;
    private TextView text_test;
    private TextView text_test1;

    @SuppressLint("HandlerLeak")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //这里是界面打开后 最先运行的地方
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //一般先用来进行界面初始化 控件初始化  初始化一些参数和变量。。。。。
        //不恰当比方    类似于 单片机的   main函数

        ui_init();//变量初始化，规范化写法
//        btn_1=findViewById(R.id.btn_1);   // 寻找xml里面真正的id  与自己定义的id绑定
        btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(led_flag == 0)
                {

                    //publishmessageplus(mqtt_pub_topic,"1");
                    publishmessageplus(mqtt_pub_topic1,"{\"led_on\":11}");
                    //publishmessageplus(mqtt_pub_topic,"{\"method\":\"/a1cmeAg0g4h/esp8266/user/shuibeng\",\"params\":{\"WaterOutletSwitch\":0}}");
                    // publishmessageplus(mqtt_pub_topic,"{\"method\":\"thing.service.property.set\",\"id\":\"2001936421\",\"params\":{\"WaterOutletSwitch\":0},\"version\":\"1.0.0\"}");
                    led_flag =1;
                }else{
                    //publishmessageplus(mqtt_pub_topic,"0");
                    publishmessageplus(mqtt_pub_topic1,"{\"led_of\":10}");
                    //publishmessageplus(mqtt_pub_topic,"{\"method\":\"/a1cmeAg0g4h/esp8266/user/shuibeng\",\"params\":{\"WaterOutletSwitch\":1}}");
                    // publishmessageplus(mqtt_pub_topic,"{\"method\":\"thing.service.property.set\",\"id\":\"2001936421\",\"params\":{\"WaterOutletSwitch\":1},\"version\":\"1.0.0\"}");
                    led_flag =0;
                }
            }
        });
        //到这里学会了按钮单击事件，
        // 举一反三，接下来是进行图片单击事件
//        image_1 =findViewById(R.id.image_1);
        image_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,"25℃" ,Toast.LENGTH_SHORT).show();
                text_test.setText("25℃");
//                publishmessageplus(mqtt_pub_topic,"open_led");

            }
        });
        Mqtt_init();
        startReconnect();
        //  两个控件联动    按钮单机 更改 textview 的内容
        handler = new Handler() {
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                switch (msg.what){

                    case 1: //开机校验更新回传
                        break;
                    case 2:  // 反馈回传

                        break;
                    case 3:  //MQTT 收到消息回传   UTF8Buffer msg=new UTF8Buffer(object.toString());
                        //显示收到的消息
                         Toast.makeText(MainActivity.this,msg.obj.toString() ,Toast.LENGTH_SHORT).show();//弹窗功能
//                        text_test.setText(msg.obj.toString());
                        //取出温度值
                        //处理message 传过来的 obj字段（里面包了数据）

//                        String T_val = msg.obj.toString().substring(msg.obj.toString().indexOf("temperature\":")+13,msg.obj.toString().indexOf("}"));
//                        String T_val = msg.obj.toString().substring(msg.obj.toString().indexOf("value\":")+7,msg.obj.toString().indexOf("value\":")+9);
//                        Toast.makeText(MainActivity.this,msg.obj.toString() ,Toast.LENGTH_SHORT).show();//弹窗功能
                        String T=msg.obj.toString().substring(msg.obj.toString().indexOf("user\"/")+25,msg.obj.toString().indexOf("user\"/")+30);
                        Toast.makeText(MainActivity.this,T ,Toast.LENGTH_SHORT).show();//弹窗功能
                        String S = "wendu";
                        String S1 = "shidu";
                        if(T.equals(S)) {
                            String T_val = msg.obj.toString().substring(msg.obj.toString().indexOf("Temperature\":") + 13, msg.obj.toString().indexOf("Temperature\":") + 15);
                            String text_val = "温度：" + T_val + " ℃";
                            text_test.setText(text_val);
                        }
                        if(T.equals(S1)) {
                            String T_val1 = msg.obj.toString().substring(msg.obj.toString().indexOf("EnvHumidity\":")+13,msg.obj.toString().indexOf("EnvHumidity\":")+15);
                            String text_val1 = "湿度："+T_val1+ " %";
                            //在主进程 handler 里面更新UI  既保证了稳定性  又不影响网络传输
                            text_test1.setText(text_val1);
                        }
                        break;
                    case 30:  //连接失败
                        Toast.makeText(MainActivity.this,"连接失败" ,Toast.LENGTH_SHORT).show();
                        break;
                    case 31:   //连接成功
                        Toast.makeText(MainActivity.this,"连接成功" ,Toast.LENGTH_SHORT).show();
                        try {
                            client.subscribe(mqtt_sub_topic, 1);
                        } catch (MqttException e) {
                            e.printStackTrace();
                        }
                        try {
                            client.subscribe(mqtt_sub_topic1,1);
                        } catch (MqttException e) {
                            e.printStackTrace();
                        }
                        break;
                    default:
                        break;
                }
            }
        };
    }
    private void ui_init() {
        btn_1=findViewById(R.id.btn_1);   // 寻找xml里面真正的id  与自己定义的id绑定
        image_1 =findViewById(R.id.image_1);
        text_test =findViewById(R.id.text_test);
        text_test1 =findViewById(R.id.text_test1);

    }
    private void Mqtt_init()
    {
        try {
            //host为主机名，test为clientid即连接MQTT的客户端ID，一般以客户端唯一标识符表示，MemoryPersistence设置clientid的保存形式，默认为以内存保存
            client = new MqttClient(host, mqtt_id,
                    new MemoryPersistence());
            //MQTT的连接设置
            options = new MqttConnectOptions();
            //设置是否清空session,这里如果设置为false表示服务器会保留客户端的连接记录，这里设置为true表示每次连接到服务器都以新的身份连接
            options.setCleanSession(false);
            //设置连接的用户名
            options.setUserName(userName);
            //设置连接的密码
            options.setPassword(passWord.toCharArray());
            // 设置超时时间 单位为秒
            options.setConnectionTimeout(70);
            // 设置会话心跳时间 单位为秒 服务器会每隔1.5*20秒的时间向客户端发送个消息判断客户端是否在线，但这个方法并没有重连的机制
            options.setKeepAliveInterval(100);
            //设置回调
            client.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {
                    //连接丢失后，一般在这里面进行重连
                    System.out.println("connectionLost----------");
                    //startReconnect();
                }
                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    //publish后会执行到这里
                    System.out.println("deliveryComplete---------"
                            + token.isComplete());
                }
                @Override
                public void messageArrived(String topicName, MqttMessage message)
                        throws Exception {
                    //subscribe后得到的消息会执行到这里面
                    System.out.println("messageArrived----------");
                    Message msg = new Message();
                    msg.what = 3;   //收到消息标志位
                    msg.obj = topicName + "---" + message.toString();
                    handler.sendMessage(msg);    // hander 回传
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void Mqtt_connect() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if(!(client.isConnected()) )  //如果还未连接
                    {
                        client.connect(options);
                        Message msg = new Message();
                        msg.what = 31;
                        handler.sendMessage(msg);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Message msg = new Message();
                    msg.what = 30;
                    handler.sendMessage(msg);
                }
            }
        }).start();
    }
    private void startReconnect() {
        scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                if (!client.isConnected()) {
                    Mqtt_connect();
                }
            }
        }, 0 * 1000, 10 * 1000, TimeUnit.MILLISECONDS);
    }
    private void publishmessageplus(String topic,String message2)
    {
        if (client == null || !client.isConnected()) {
            return;
        }
        MqttMessage message = new MqttMessage();
        message.setPayload(message2.getBytes());
        try {
            client.publish(topic,message);
        } catch (MqttException e) {

            e.printStackTrace();
        }

    }
}
