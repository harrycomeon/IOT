#ifndef __SWITCH_H
#define __SWITCH_H	 
#include "sys.h"

#define SWITCH0 PAout(6)// PA6
#define SWITCH1 PAout(7)// PA7
#define SWITCH2 PGout(6)// PG6
#define SWITCH3 PGout(8)// PG8

void SWITCH_Init(void);//��ʼ��

		 				    
#endif
