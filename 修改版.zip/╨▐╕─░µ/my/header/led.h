#ifndef _LED_H
#define _LED_H
#include "stm32f10x.h"

#define led_off 	GPIO_SetBits(GPIOB,GPIO_Pin_12)
#define led_on 		GPIO_ResetBits(GPIOB,GPIO_Pin_12)

void led_init(void);
void SetLed(u8 num,u16 on_time,u16 off_time);
void Led_10mS_Conut(void);//������10mS��������


#endif

