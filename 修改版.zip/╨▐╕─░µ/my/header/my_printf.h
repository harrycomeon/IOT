#ifndef _MY_PRINTF_H_
#define _MY_PRINTF_H_

#include "SEGGER_RTT.h" 
#include "stdarg.h"






#endif