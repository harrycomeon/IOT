#ifndef __CONNECT_H
#define __CONNECT_H

#include "stm32f10x.h"
//#include "pro_data.h"


#define LIVE_INTERVAL (3000)	//�����������,��λ10ms(60��)
static const char* USERNAME = "stm32&a1JxOUTX7DV";	//�豸����
static const char* PASSWARD = "5bdfa0e3372d3e812000fc1edd3572b8786ac216";	//�豸������
static const char* TCP_ADDR = "a1JxOUTX7DV.iot-as-mqtt.cn-shanghai.aliyuncs.com";	//��������ַ

//esp8266
enum ESP_MODE
{
	ESP_CLIENT,
	ESP_SERVER
};

enum ESP_STATE
{
	WAIT_LOGIN,
	SATRT_CONNECT,
	BIND,
	LIVE,
	SENSOR_UPDATE,
	SERVER
};

enum ESP_UPDATEMODE
{
	UPDATE,
	UPLOAD
};

typedef struct
{
	u32 ser_time;
	u32 timer;
	u32 last_http;
	u16 port;
	u8 state;
	u8 mode;
	u8 connect;
	u8 bind;
	u8 login_flag;//����
	u8 login;
	u8 sensor;
	u8 ishttpget;
	u8 ssid[16];
	u8 pwd[16];
	
}ESP8266_obj;

typedef struct
{
	u16 port;
	u8 host[32];
	u8 clientID[16];
	u8 username[16];
	u8 password[16];
	u8 connect_state;
	u8 msg_type;
}MQTT_obj;
extern ESP8266_obj esp8266;


void Connect_Init(void);
void ESP_Connect(void);
void ESP_SensorUpdate(u8 addr,u8 val,u8 type);
u8 my_strstr(char *str1,char *str2,u16 str1_len);
u8 ESP_PostData(char *data);//send the HTTP PUT requestw
u8 MQTT_keep_alive(void);
u8 MQTT_Publish(char *pTopic,char *pMessage,u16 timeout);
void string_printf_0x(char *p,u32 len);
u8 MQTT_Publish_attribute(char *pTopic,char *key_word,char *pMessage,u16 timeout);
u8 MQTT_Connect(char *username,char *password,u16 timeout);
u8 MQTT_Subscrib(char *pTopic,u16 timeout);
void MQTT_Subscrib_Message(char *my_buf,char *recv_buf,char *pTopic,u16 recv_len);
#endif
