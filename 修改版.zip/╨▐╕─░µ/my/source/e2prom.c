#include "e2prom.h"

void e2prom_init(){

}

