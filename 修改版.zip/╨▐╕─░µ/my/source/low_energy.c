#include "low_energy.h"



void low_energy_init(){


}

