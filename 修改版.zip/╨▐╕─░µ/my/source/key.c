#include "key.h"


void key_init(void){

}


u8 key_scanf(void){

}